package com.morningstar;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
//import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.morningstar.Repository.CustomerRepository;
import com.morningstar.entity.Customer;
import com.morningstar.service.CustomerService;

public class CustomerServiceTesting {
	@SpringBootTest(classes= {CustomerServiceTesting.class})
	public class MockitoServiceTest {



	   @Mock
	    CustomerRepository customerRepository;
	    
	    @InjectMocks
	    CustomerService customerService;
	    
	    //public List<Registration> register;
	    
	    @Test
	    @Order(1)
	    public void test_getAllRegistration() {
	        
	        List<Customer> register = new ArrayList<>();
	        
	        register.add(new Customer(1001, "akash", "apj@123", "8888"));
	        register.add(new Customer(1002, "sanket", "snk@123", "1111"));
	        register.add(new Customer(1001, "harshada", "hrsd@123", "2222"));
	        
	        when(customerRepository.findAll()).thenReturn(register);
	        
	        
	        Assertions.assertEquals(3,customerService.getAllCustomer(register).size());
	        
	    }
	}}
