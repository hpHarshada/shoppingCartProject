package com.morningstar.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse {
	private int statuscode;
	private String message;
	public ErrorResponse() {
		super();
		
	}
	public ErrorResponse( String message) {
		super();
		this.message = message;
	}
	
	public ErrorResponse(int statuscode, String message) {
		super();
		this.statuscode = statuscode;
		this.message = message;
	}

	public int getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
