package com.morningstar.exception;

public class InvalidUserException extends RuntimeException{
	private String messesge;
	public InvalidUserException(String messege) {
		this.messesge = messege;
	}
	

}
