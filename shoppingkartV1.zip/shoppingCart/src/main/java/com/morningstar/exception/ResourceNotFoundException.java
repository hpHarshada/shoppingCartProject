package com.morningstar.exception;

public class ResourceNotFoundException extends RuntimeException {
	private String msg;

	public ResourceNotFoundException(String msg) {
		super();
		// TODO Auto-generated constructor stub
		this.msg =msg;
	}
	

}
