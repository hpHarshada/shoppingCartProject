package com.morningstar.exception;

public class CustomerServiceException extends RuntimeException{
	private String msg;

//	public CustomerServiceException(msg) {
//		super(msg);
//		
//	}
	public CustomerServiceException(String msg) {
		super(msg);
		this.msg = msg;
		
	}


}
