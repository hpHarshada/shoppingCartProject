package com.morningstar.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.morningstar.Repository.ProductRepository;
import com.morningstar.entity.Product;


@Service
public class ProductService {
	private ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getAllProducts() {
        return this.productRepository.findAll();
    }
    public Product getProduct(int id) {
        return this.productRepository.findById(id).get();
    }

}
