package com.morningstar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.morningstar.Repository.CustomerRepository;
import com.morningstar.entity.Customer;
import com.morningstar.exception.CustomerServiceException;

@Service
public class CustomerService {
	@Autowired
	CustomerRepository customerRepository;

	/**
	 * initialising through ctr
	 */
//	public CustomerService(CustomerRepository customerRepository) {
//		this.customerRepository = customerRepository;
//	}

	public Customer saveCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	public Integer isCustomerPresent(Customer customer) {
		Customer customer1 = customerRepository.getCustomerByEmailAndName(customer.getEmail(), customer.getName());
		return customer1 != null ? customer1.getId() : null;
	}
    //here authenticating customer with valid email and password
	public Customer authenticate(String email, String password)throws CustomerServiceException {
		Customer customer = customerRepository.getCustomerByEmail(email);
		System.out.println("Authenticate" + customerRepository.getCustomerByEmail(email));

		if (customer != null) {

			if (customer.getPassword().equals(password))
				return customer;
			else
				throw new CustomerServiceException("invalid Credential");

		}
		return null;

	}

	public List<Customer> getAllCustomer(List<Customer> register) {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}
}
