package com.morningstar.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.morningstar.Repository.OrderRepository;
import com.morningstar.Repository.ProductRepository;
import com.morningstar.entity.Order;
import com.morningstar.entity.Product;
import com.morningstar.entity.ShoppingCart;

//import jakarta.transaction.Transactional;

@Service
public class OrderService {
	@Autowired
	 private OrderRepository orderRepository;
	@Autowired
	private ProductRepository productRepository;



	    public Order getOrderDetail(int orderId) {
	        Optional<Order> order = this.orderRepository.findById(orderId);
	        return order.isPresent() ? order.get() : null;
	    }

	    public float getCartAmount(List<ShoppingCart> shoppingCartList) {

	        float totalCartAmount = 0f;
	        float singleCartAmount = 0f;
	        int availableQuantity = 0;

	        for (ShoppingCart cart : shoppingCartList) {

	            int productId = cart.getProductId();
	            Optional<Product> product = productRepository.findById(productId);
	            if (product.isPresent()) {
	                Product product1 = product.get();
	                if (product1.getAvailableQauntity() < cart.getQuantity()) {
	                    singleCartAmount = product1.getPrice() * product1.getAvailableQauntity();
	                    cart.setQuantity(product1.getAvailableQauntity());
	                } else {
	                    singleCartAmount = cart.getQuantity() * product1.getPrice();
	                    availableQuantity = product1.getAvailableQauntity() - cart.getQuantity();
	                }
	                totalCartAmount = totalCartAmount + singleCartAmount;
	                product1.setAvailableQauntity(availableQuantity);
	                availableQuantity=0;
	                cart.setProductName(product1.getName());
	                cart.setAmount(singleCartAmount);
	                productRepository.save(product1);
	            }
	        }
	        return totalCartAmount;
	    }

	    public Order saveOrder(Order order) {
	        return orderRepository.save(order);
	    }

}
