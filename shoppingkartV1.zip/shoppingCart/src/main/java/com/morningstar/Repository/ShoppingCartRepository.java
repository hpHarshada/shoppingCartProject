package com.morningstar.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.morningstar.entity.ShoppingCart;

public interface ShoppingCartRepository extends JpaRepository<ShoppingCart, Integer>{

}
