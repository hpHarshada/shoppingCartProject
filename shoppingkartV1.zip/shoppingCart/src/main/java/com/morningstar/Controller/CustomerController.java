package com.morningstar.Controller;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.morningstar.credentials.Credentials;
import com.morningstar.entity.Customer;
import com.morningstar.exception.CustomerServiceException;
//import com.morningstar.exception.InvalidUserException;
import com.morningstar.service.CustomerService;



@RestController
@RequestMapping("/api")
public class CustomerController {
	
	 @Autowired
	private CustomerService customerService;
	 private Logger logger = LoggerFactory.getLogger(OrderController.class);

//	public CustomerController(CustomerService customerService) {
//		super();
//		this.customerService = customerService;
//	}
	
	@PostMapping("/signup")
	public ResponseEntity<Customer> saveCustomer(@RequestBody Customer customer)  {
		customerService.saveCustomer(customer);
		if(customer != null) {
			logger.info("signed up succesfully : " + customer.getName());
			return ResponseEntity.ok(customer);}
	
     	else return null;
	}
    
    	
    
	@PostMapping("/login")
	public ResponseEntity<Customer> authenticate(@RequestBody Credentials cred)throws CustomerServiceException{
		Customer customer = customerService.authenticate(cred.getEmail(), cred.getPassword());
		if(customer == null) 
			return null;
		
		//System.out.println("logged in succesfully");
		logger.info("logged in succesfully : " + cred.getEmail());
		return ResponseEntity.ok(customer);
	}
	
	
	
    
}
