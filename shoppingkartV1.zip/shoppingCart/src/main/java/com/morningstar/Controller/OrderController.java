package com.morningstar.Controller;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.morningstar.dto.OrderDto;
import com.morningstar.dto.ResponseOrderDto;
import com.morningstar.entity.Customer;
import com.morningstar.entity.Order;
import com.morningstar.service.CustomerService;
import com.morningstar.service.OrderService;
import com.morningstar.util.DateUtil;


@RestController
@RequestMapping("/api")
public class OrderController {
	@Autowired
	private OrderService orderService;
	@Autowired
	private CustomerService customerService;
//	@Autowired
//	OrderDto orderDto;
//	@Autowired
//	 ResponseOrderDto responseOrderDto;
	 private Logger logger = LoggerFactory.getLogger(OrderController.class);
	
	@PostMapping("/placeOrder")
    public ResponseEntity<ResponseOrderDto> placeOrder(@RequestBody OrderDto orderDTO) {
		OrderDto orderDto = new OrderDto();
		ResponseOrderDto responseOrderDto = new ResponseOrderDto ();
        logger.info("Request Payload " + orderDTO.toString());
        
        
        float amount = orderService.getCartAmount(orderDTO.getCartItems());

        Customer customer = new Customer(orderDto.getCustomerName(), orderDto.getCustomerEmail());
        Integer customerIdFromDb = customerService.isCustomerPresent(customer);
        if (customerIdFromDb != null) {
            customer.setId(customerIdFromDb);
            logger.info("Customer already present in db with id : " + customerIdFromDb);
        }else{
            customer = customerService.saveCustomer(customer);
            logger.info("Customer saved.. with id : " + customer.getId());
        }
        Order order = new Order(orderDto.getOrderDescription(), customer, orderDTO.getCartItems());
        order = orderService.saveOrder(order);
        logger.info("Order processed successfully..");

        responseOrderDto.setAmount(amount);
        responseOrderDto.setDate(DateUtil.getCurrentDateTime());
        responseOrderDto.setInvoiceNumber(new Random().nextInt(1000));
        responseOrderDto.setOrderId(order.getId());
        responseOrderDto.setOrderDescription(orderDTO.getOrderDescription());

        logger.info("test push..");

        return ResponseEntity.ok(responseOrderDto);
    }

    @GetMapping(value = "/getOrder/{orderId}")
    public ResponseEntity<Order> getOrderDetails(@PathVariable int orderId) {

        Order order = orderService.getOrderDetail(orderId);
        return ResponseEntity.ok(order);
    }


}

