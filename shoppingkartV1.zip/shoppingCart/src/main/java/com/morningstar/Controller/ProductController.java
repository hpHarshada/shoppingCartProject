package com.morningstar.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.morningstar.entity.Product;
import com.morningstar.service.ProductService;




@RestController
@RequestMapping("/api")
public class ProductController {
	 @Autowired
	 private ProductService productService;
	 
	 @GetMapping(value = "/getAllProducts")
	    public ResponseEntity<List<Product>> getAllProducts() {

	        List<Product> productList = productService.getAllProducts();

	        return ResponseEntity.ok(productList);
	    }
	 
	 @GetMapping(value = "/getProduct/{id}")
	 public ResponseEntity<Product>getProduct(@PathVariable("id")int id){
		 Product product = productService.getProduct(id);
		return ResponseEntity.ok(product);
		 
	 }
 
	 
	

}
